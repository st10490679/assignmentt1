package za.ac.iie.myassignmentt1

import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val breakfast = findViewById<RadioButton>(R.id.rdbreakfast)
        val brunch = findViewById<RadioButton>(R.id.rdbrunch)
        val lunch = findViewById<RadioButton>(R.id.rdlunch)
        val snack = findViewById<RadioButton>(R.id.rdsnack)
        val dinner = findViewById<RadioButton>(R.id.rddinner)
        val dessert = findViewById<RadioButton>(R.id.rddessert)

        val reset = findViewById<Button>(R.id.btnreset)
        val suggest = findViewById<Button>(R.id.btnsuggest)

        val suggestionText = findViewById<TextView>(R.id.txtsuggest)
        suggest.setOnClickListener {
            if (breakfast.isChecked) {
                suggestionText.text = "Breakfast wrap"
            } else if (brunch.isChecked) {
                suggestionText.text = "yoghurt bowl"
            } else if (lunch.isChecked) {
                suggestionText.text = "chicken wrap"
            } else if (snack.isChecked) {
                suggestionText.text = "peanuts"
            } else if (dinner.isChecked) {
                suggestionText.text = "steak and veggies"
            } else if (dessert.isChecked) {
                suggestionText.text = "ice cream "
            }
            else {
              suggestionText.text = "Please select a time of day to get a meal suggestion"
            }
        }

            reset.setOnClickListener {
                val group = findViewById<RadioGroup>(R.id.radiogroup)
                group.clearCheck()


                suggestionText.text = ""

            }


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}